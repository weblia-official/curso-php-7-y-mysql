<?php
//Primero comprobamos si se envió el formulario

if(isset($_POST['enviar'])){
    //Comprobamos que sea el tipo que necesitamos
    $tipos = array('image/png', 'image/jpeg');
    //Checamos que el tipo de archivo esté en nuestro array de tipos
    if(in_array($_FILES['miArchivo']['type'], $tipos)){
        var_dump($_FILES);
        
        //8 bits son 1 byte
        //1024 bytes son 1 kilobyte
        //1024 Kilobytes son 1 megabyte

        $tamanio = 1024 * 1024 * 10;
        // 1024 bytes * 1024 kilobytes = 1 megabyte
        // después lo multiplicamos por 10 para que sean 10 megabytes

        //Checamos que cumpla el tamaño
        if($_FILES['miArchivo']['size'] < $tamanio){
            //Si el archivo cumple el tamaño
            //Subimos el archivo

            //Primero definimos la carpeta en la que se subirá
            $carpeta = 'publicaciones/';

            //Después checamos si no existe la carpeta
            if(!file_exists($carpeta)){
                //Si la carpeta no existe la creamos
                mkdir($carpeta);
            }
            //Podemos subirlo con su nombre original o algo más eficiente para que no se repita
            $tipo = $_FILES['miArchivo']['type'];
            $fecha = date("Ymd-His");
            if($tipo == "media/jpeg"){
                $archivo = $carpeta.$fecha.".jpg";
            }else{
                $archivo = $carpeta.$fecha.".png";
            }
            
            $tmpName = $_FILES['miArchivo']['tmp_name'];
            //Después checamos si el archivo no existe
            if(!file_exists($archivo)){
                //Si el archivo no existe lo subimos, la función movel_uploaded file
                //va a recibir la ruta en la que está el archivo, y a donde lo queremos mover
                if(move_uploaded_file($tmpName,$archivo)){
                    echo "El archivo se subió correctamente";
                }else{
                    echo "Hubo un error al subir el archivo";
                }
            }else{
                echo "El archivo ya existe";
            }
        }else{
            echo "Solo aceptamos archivos de menos de 10megabytes";
        }
    }else{
        echo "Solo admitimos tipos jpg y png";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Subiendo archivos</title>
</head>
<body>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
        Selecciona el archivo  subir
        <input type="file" name="miArchivo">
        <input type="submit" name="enviar" value="Subir">
    </form>
</body>
</html>