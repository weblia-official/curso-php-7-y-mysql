<?php

//Para crear una cookie vamos a utilizar la función setcookie

//setcookie("nombre", "Valor", Fecha de expiración);

//La fecha de expiración debe ser expresada con la función time() + el tiempo en segundos.
//La función time() nos devuelve la fecha unix actual en segundos, y le tenemos que sumar los segundos que necesitamos

setcookie('apellido', 'Valdes', time() + 60 * 5);


//Si queremos imprimir el valor de una cookie llamamos 

echo $_COOKIE['apellido'];

//Si queremos eliminar una cookie, basta con que pongamos el valor de la fecha, en una fecha anterior a la actual

//setcookie('apellido', 'Valdes', time() - 1);

//Las cookies se guardan aunque el usuario cierre el navegador hasta su fecha de expiración

