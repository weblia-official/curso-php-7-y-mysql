<?php
session_start();
if(isset($_SESSION['usuario'])){
    //Si existe la session de usuario mandamos a la página de logueado
    header('Location:logueado.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Inicio de sesión rápido</h2>
    <form action="iniciar.php" method="POST">
        Escribe tu nombre de usuario: 
        <input type="text" name="user">
        <input type="submit" value="Enviar" name="enviar">
    </form>
</body>
</html>