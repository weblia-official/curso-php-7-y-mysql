<?php
$fondo = "#fff";
if(isset($_POST['enviar'])){
    //Se envió el formulario
    $color = $_POST['colorFav'];

    if($color == "verde"){
        //setcookie('color','verde', time() + 60 * 60 * 24 * 30);
        $_SESSION['color'] = 'verde';
    }else if($color == "azul"){
        //setcookie('color','azul', time() + 60 * 60 * 24 * 30);
        $_SESSION['color'] = 'azul';
    }
}

    if(isset($_SESSION['color'])){
        //Si existe la cookie llamada color, entonces nos fijamos si su valor es verde
        if($_SESSION['color'] == "verde"){
            $fondo = "#33ca7f";
        }else if($_SESSION['color'] == "azul"){
            //si la cookie es igual a azul
            $fondo = "#90bede";
        }
    } 
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cambiando el color con SESSION</title>
</head>
<?php echo "<body style=\"background:".$fondo.";\">"; ?>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        Elige tu color favorito para el fondo:
        Verde
        <input type="radio" name="colorFav" value="verde">
        Azul
        <input type="radio" name="colorFav" value="azul">
        <input type="submit" value="Enviar" name="enviar">
    </form>
</body>
</html>