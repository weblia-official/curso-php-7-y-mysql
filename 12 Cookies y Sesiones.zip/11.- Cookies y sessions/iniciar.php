<?php
session_start();
if(!isset($_SESSION['usuario'])){
    //Verificamos si no existe la sesión

    if(isset($_POST['enviar'])){
        //Verificamos que se envió el formulario
        //Guardamos el usuario enviado en una variable
        $usuario = $_POST['user'];

        $_SESSION['usuario'] = $usuario;

        echo "Iniciaste sesión como: ".$_SESSION['usuario']."<br>";

    }else{
        echo "No has enviado el usuario";
        echo "<br>";
    }
}else{
    //Si la sesión ya existe, le decimos que si quiere cerrar sesión
    echo "Estas logueado como ".$_SESSION['usuario'];
    echo "<br>";
    echo "¿Quieres cerrar sesión?";
    echo "<br>";
    echo "<a href='logout.php'>Click aqui para cerrar sesión</a>";
    echo "<br>";
}



?>
<a href="usuario.php">Regresar a el formulario</a>