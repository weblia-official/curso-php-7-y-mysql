<?php
session_start();
if(!isset($_SESSION['usuario'])){
    //Si no existe la sesión de usuario lo mandamos a la página de logueo
    header("Location: usuario.php");
}

?>

<h2>Está página la ves por que estás logueado</h2>
<a href="logout.php">Cerrar sesión</a>
