<?php

//Para usar sesiones, debemos iniciar la session con session_start(), esto debe ir antes de cualquier código HTML
session_start();
//se recomienda que esté siempre al inicio del código

//Después creamos la session

//$_SESSION['nombredelasession'] = "Valor de la session";

$_SESSION['usuario'] = 'carlos26';
$_SESSION['contrasena'] = "nomerobes";
$_SESSION['edad'] = 15;

//Las sesiones se pierden si el usuario cierra el navegador

//O podemos destruir la session con session_destroy()