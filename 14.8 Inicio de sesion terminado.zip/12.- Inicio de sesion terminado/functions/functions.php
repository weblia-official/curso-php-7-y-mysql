<?php

function esVacia($usuario, $contrasena, $repContrasena){
    //Checamos si los valores vienen vacíos
    if(!empty(trim($usuario)) && !empty(trim($contrasena)) && !empty(trim($repContrasena))){
        //trim quita los espacios en blanco al inicio o al final, así que checamos que no tenga espacios y que no vegnga vacía
        //Ya que si nos envian un espacio no se considera vacía por eso usamos trim
        
       //Si no están vacías, regresamos FALSO, por que es falso que estén vacias
        return FALSE;
    }else{
        //Si alguna variable está vacía regresamos TRUE, por que es verdadero que una variable está vacía
        return TRUE;
    }
}

//Función que comprueba que el nombre de usuario tenga más de 3 caracteres pero menos de 20
function validaLargo($usuario){
    //Si está dentro del límite devolvemos TRUE, si no está dentro del limite devolvemos FALSE
    if(strlen(trim($usuario)) > 3 && strlen(trim($usuario)) < 20){
        //strlen nos regresa el largo en caracteres de una cadena
        return TRUE;
    }else{
        //Si la cadena es más corta o más larga
        return FALSE;
    }
}

//Esta función busca a un usuario para ver si ya existe en la base de datos.
function usuarioExiste($usuario){
    //Si el usuario existe regresa TRUE, si el usuario no existe regresa FALSE
    global $mysqli;
    //Llamamos a la variable de conexión $mysqli
    $_usuario = trim($usuario);
    //Usaremos sentencias preparadas para hacer más seguro nuestro sistema
    $sql = "SELECT id FROM users WHERE usuario = ?";

    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('s', $_usuario);
    //Ejecutamos la sentencia
    $stmt->execute();

    $stmt->store_result();
    $numRows = $stmt->num_rows;
    $stmt->close();

    if($numRows > 0){
        //Si el número de filas es mayor a 0 significa que el usuario existe
        return TRUE;
    }else{
        return FALSE;
    }
 
}
//Esta función verifica si las dos contraseñas son iguales
function contrasenasIguales($contrasena, $repContrasena){
    //Si las contraseñas son iguales devuelve TRUE, si no son iguales devuelve FALSE
    if(strcmp($contrasena, $repContrasena) == 0){
        //La función strcmp compara dos cadenas, considera mayúsculas y minúsculas, y devuelve cero si son iguales
        return TRUE;
    }else{
        return FALSE;
    }
}
//Esta función crea un hash del password para insertarlo en la base de datos
function hashContrasena($contrasena){

    $hash = password_hash($contrasena, PASSWORD_DEFAULT);
    return $hash;
}
function registra($usuario, $contrasena){
    global $mysqli;
    //Quitamos los espacios del nombre de usuario
    $_usuario = trim($usuario);
    $fecha = date("Y-m-d H:i:s");
    $id = NULL;
    $ultima = NULL;
    //Aquí la contrasena ya debe venir hasheada

    $sql = "INSERT INTO users(usuario,contrasena,fecha_registro) VALUES(?,?,?)";

    $stmt = $mysqli->prepare($sql);
    
    $stmt->bind_param("sss",$_usuario, $contrasena, $fecha);

    if($stmt->execute()){
       
        //Si se ejecuta correctamente, entonces se registró el usuario
        $stmt->close();
        return TRUE;
    }else{
        //De lo contrrio hubo un error
        $stmt->close();
        return FALSE;
    }
}


function loginVacio($usuario, $contrasena){
    //Checamos si los valores vienen vacíos
    if(!empty(trim($usuario)) && !empty(trim($contrasena))){
        //trim quita los espacios en blanco al inicio o al final, así que checamos que no tenga espacios y que no vegnga vacía
        //Ya que si nos envian un espacio no se considera vacía por eso usamos trim
        
       //Si no están vacías, regresamos FALSO, por que es falso que estén vacias
        return FALSE;
    }else{
        //Si alguna variable está vacía regresamos TRUE, por que es verdadero que una variable está vacía
        return TRUE;
    }
}

function login($usuario,$contrasena){

    global $mysqli;

    $sql = "SELECT id,contrasena FROM users WHERE usuario = ?";

    $stmt = $mysqli->prepare($sql);

    $stmt->bind_param("s",$usuario);

    $stmt->execute();

    $stmt->store_result();

    $num_rows = $stmt->num_rows;

    //Checamos que el num_rows sea mayor a 0

    if($num_rows > 0){
        //Listamos el resultado
        $stmt->bind_result($id,$contra);
        $stmt->fetch();

        //Después con la función pass_verify, checamos que el hash en la base de datos coincida con la contrasena
        $contraValidada = password_verify($contrasena, $contra);

        //Si la contraseña coincide, procedemos a hacer el login
        if($contraValidada){
            //Si la contraseña fué validada, entonces actualizamos la última conexión y creamos las sesiones
            $_SESSION['user'] = $usuario;
            //Actualizamos la última vez que se conectó
            $lastSession = lastSession($id);
            //Reedirigimos a la página de inicio
            header('Location:index.php');
        }else{
            return "Las contraseñas no coinciden";
        }
    }else{
        return "Ese usuario no existe";
    }
}

function lastSession($id){
    global $mysqli;
    //Esta función modifica la última vez que se conectó el usuario
    $stmt = $mysqli->prepare("UPDATE users SET ultima_conexion=NOW() WHERE id = ?");
    $stmt->bind_param("i",$id);
    if($stmt->execute()){
        if($stmt->affected_rows > 0){
            return TRUE;
        }else{
            return FALSE;
        }
        
    }else{
        return FALSE;
    }
    $stmt->close();
}


