<?php
//Tenemos que checar que no existe la session
if(isset($_SESSION['user'])){
    //Si la sesión existe los reedirigimos al index
    header('Location:index.php');
}

