<?php
//Comenzamos iniciando session
session_start();

require('functions/connection.php');
require('functions/functions.php');
//Comprobamos que no exista la sesion
require('functions/sesion.php');

$errors = array();
    //Comprobamos que se envió el formulario, con el botón enviar
    if(isset($_POST['enviar'])){
        //Si el formulario se envió, guardamos las variables, escapándolas
        $usuario = $mysqli->real_escape_string($_POST['usuario']);
        $contrasena = $mysqli->real_escape_string($_POST['contrasena']);
        $repContrasena = $mysqli->real_escape_string($_POST['repContrasena']);

        //Ahora verificamos que los datos no vengan vacíos
        if(!esVacia($usuario,$contrasena,$repContrasena)){
            //La función esVacia verifica, si nuestros datos están vacíos, si alguno está vacio regresa TRUE, si no están vacíos regresa FALSE.
            //Por eso negamos la función, por que si me regresa FALSE, los datos están correctos, entonces la niego para que sea TRUE
            //y entre en el if
            
            //Ahora validamos que no sean solo números
            if(!is_numeric($usuario)){
                //is_numeric nos devuelve TRUE si son números, por eso lo niego, por que lo correcto es que no sean números
                //por lo cual nos devolvería FALSE, y negado sería TRUE, entonces entraría al IF

                //Comprobamos que el usuario tenga más de 3 caracteres pero menos que 20 con la función validaLargo
                if(validaLargo($usuario)){
                    //Si nos regresa TRUE es válida

                    //Ahora comprobamos si el usuario no existe en la Base de datos
                    if(!usuarioExiste($usuario)){
                        //Si el usuario existe nos devuelve TRUE, si no existe que es lo que esperamos nos devuelve FALSE, por eso negamos

                        //Si el usuario no existe entonces comprobamos que los password sean iguales
                        if(contrasenasIguales($contrasena, $repContrasena)){
                            //Si las contraseñas son iguales entonces procedemos a registrar al usuario
                            //Primero creamos el hash de la contraseña
                            echo $hash = hashContrasena($contrasena);

                            if(registra($usuario,$hash)){
                                $resultado = "Usuario registrado con exito";
                            }else{
                                $errors[] = "Hubo un error al registrar el usuario";
                            }
                        }else{
                            $errors[] = "Las contraseñas no coinciden";
                        }
                    }else{
                        $errors[] = "El usuario ya existe, elige otro";
                    }
                }else{
                    //Si nos regresa FALSE la cadena no es válida
                    $errors[] = "El usuario debe tener más de 3 caracteres pero menos de 20";
                }


            }else{
                $errors[] = "Tu nombre de usuario no pueden ser solo números";
            }
        }else{
            $errors[] = "Debes rellenar todos los campos";
        }
    }

?>
<?php
//Incluimos el header
include('templates/header.php');
?>

    <div class="container">
        <div class="row mt-5">

            <div class="col-8 m-auto bg-white rounded shadow p-0">
            <h4 class="text-center mb-4 text-secondary mt-5">REGÍSTRATE EN NUESTRA PÁGINA WEB</h4>
            <div class="col-12 bg-light py-3 mb-5 text-center">
            <p class="text-secondary m-0 p-0">Regístrate en nuestra web para obtener excelentes beneficios.</p>
            </div>
            <?php if(isset($resultado)){ ?>
            <div class="bg-success text-white p-2 mx-5 text-center">
                <?php echo $resultado; ?>
            </div>
            <?php } ?>
            <?php

                include('functions/errors.php');                              
            ?>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="m-5">

                    <label for="" class="text-secondary">Usuario:</label>
                    <div class="input-group mb-5">
                        <div class="input-group-prepend">
                            <i class="input-group-text bg-primary text-white fas fa-user"></i>
                        </div>
                        <!-- Input para el usuario -->
                        <input type="text" placeholder="Nombre de usuario" autocomplete="off" name="usuario" class="form-control">
                    </div>

                    <div class="form-row">

                        <div class="col-6 mb-3">
                            <label for="" class="text-secondary">Contraseña:</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                <i class="input-group-text bg-primary text-white fas fa-key"></i>
                                </div>
                                <!-- Input para la contraseña -->
                                <input type="password" placeholder="Contraseña" name="contrasena" class="form-control">
                            </div>
                        </div>

                        <div class="col-6 mb-3">
                            <label for="" class="text-secondary">Repite la contraseña:</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                <i class="input-group-text bg-primary text-white fas fa-key"></i>
                                </div>
                                <!-- Input para la repetición de la contraseña -->
                                <input type="password" placeholder="Repite tu contraseña" name="repContrasena" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-4 offset-8">
                            <!-- Input del botón para enviar el formulario -->
                            <input type="submit" class="form-control btn btn-primary" name="enviar" value="Registrarme">
                        </div>
                      
                    </div>
                   
                </form>
                <div class="col-4 m-5">
                            <a href="login.php"><button class="btn btn-outline-secondary form-control">Iniciar sesión</button></a>
                            <p class="text-secondary text-center">¿Ya tienes cuenta?</p>
                </div>
            </div>
        </div>
    </div>

<?php
include('templates/footer.php');
?>