<?php
//Comenzamos iniciando session
session_start();

require('functions/connection.php');
require('functions/functions.php');

if(!isset($_SESSION['user'])){
    //Si no existe la sesión reedigirimos a login.php
    header('Location:login.php');
}

$errors = array();

?>
<?php
//Incluimos el header
include('templates/header.php');
?>

    <div class="container">
        <div class="row mt-5">

            <div class="col-8 m-auto bg-white rounded shadow p-0">
                <h4 class="text-center mb-4 text-secondary mt-5">INDEX</h4>
                <div class="col-12 bg-light py-3 mb-5 text-center">
                <button class="btn btn-success m-auto">Agregar publicación</button>
                </div>
            <?php
                include('functions/errors.php');                              
            ?>
                <div class="px-5 pb-5"><h4>Estás logueado como: <?php echo $_SESSION['user']; ?></h4>

                    <div class="publicacion border-bottom">
                        <img src="img/publicacion.jpg" class="rounded img-fluid" alt="">
                        <h4 class="my-2">Mi viaje a antártida</h4>
                        <p class="text-muted">2020-03-05 12:27:12</p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id suscipit temporibus earum magnam enim explicabo repellendus molestias natus! Minus aliquam sequi necessitatibus cupiditate qui repudiandae nesciunt rem, harum repellendus tempore.</p>
                        <p class="text-right text-muted">Publicado por: Carlos</p>
                    </div>
                </div>
                
                <div class="col-4 m-5">
                            <a href="logout.php"><button class="btn btn-outline-secondary form-control">Cerrar sesión</button></a>
                            <p class="text-secondary text-center">¿Quieres cerrar sesión?</p>
                </div>
            </div>
        </div>
    </div>

<?php
include('templates/footer.php')
?>