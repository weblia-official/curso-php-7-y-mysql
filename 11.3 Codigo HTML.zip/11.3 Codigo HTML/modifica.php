<?php
    require('connection.php');
    $errors = array();

if(isset($_POST['enviar'])){
    //echo "Se envió el formulario";
    //Si se envió el formulario, entonces checamos que todos los valores vengan
    $mi_nombre = $_POST['miNombre'];
    $mi_calificacion = $_POST['miCalificacion'];
    $mi_comentario = $_POST['miComentario'];
    $mi_id = $_POST['miId'];
    //var_dump($_POST);
    //Validamos que no estén vacíos
    if(!empty($mi_nombre) && !empty($mi_calificacion) && !empty($mi_comentario && !empty($mi_id))){
    //Este IF se lee, si mi_nombre no está vacío y mi_calificación no esta vacío y mi_comentario no está vacío
    $mi_fecha = date("Y-m-d H:i:s");
        $sql = "UPDATE comentarios SET nombre = '$mi_nombre', comentario = '$mi_comentario', calificacion = '$mi_calificacion' WHERE id='$mi_id'";
         $result = $mysqli->query($sql);
    }else{
        //Si alguna de los tres está vacío entonces es incorrecto.
        $errors[] = "Rellena todos los campos";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de comentarios</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet"> 
    <link href="css/all.min.css" rel="stylesheet">
</head>
<body>
    
    <div class="container">
        <div class="comentarios">
            <h2>Estado de la modificación del comentario</h2>
            <?php
                //Checamos si se ejecutó correctamente nuestro código
                if(isset($result)){
                    //Checamos si la variable $Result está definidca, lo cual significa que entró en el sql
                    if($result){
                        //Checamos el resultado de $result, para ver si la consulta se ejecutó correctamente
                        if($mysqli->affected_rows > 0){
                        echo "<div class='success'><i class='fas fa-check-circle'></i> Comentario modificado correctamente</div>";
                        }else{
                            $errors[] = "No se modificó ningún comentario";
                        }
                    }else{
                        $errors[] = "Sucedió un error".$mysqli->error;
                    }
                }

            ?>
            <?php                 
                    if(count($errors) > 0){
                        echo "<div class='error'>";
                        foreach($errors as $error){
                            echo "<i class='fas fa-exclamation-circle'></i> ".$error."<br>";
                        }
                        echo "</div>";
                    }

            ?>
                            <a href="index.php">Regresar a la página de inicio</a>

        </div>
    </div>
</body>
</html>