<?php 
    require('connection.php');

    $errors = array();
    if(isset($_GET['id'])){
        $idComentario = $_GET['id'];
        if(empty($idComentario)){
            $errors[] = "El id está vacío";
        }else{
            $sql = "DELETE FROM comentarios WHERE id = $idComentario";
            $result = $mysqli->query($sql);
        }
    }else{
        $errors[] = "No puedes estar en esta página";
    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de comentarios</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet"> 
    <link href="css/all.min.css" rel="stylesheet">
</head>
<body>
    
    <div class="container">
        <div class="comentarios">
            <h2>Borrar comentario</h2>
                            <div class="comentario">
                                <?php 
                                if(isset($result)){
                                    if($result){
                                        if($mysqli->affected_rows > 0){
                                        echo "<div class='success'><i class='fas fa-check-circle'></i> Comentario Borrado correctamente</div>";
                                        }else{
                                        $errors[] = "Ese comentario no existe";
                                        }
                                    }else{
                                        //Recuerden que no debemos mostrar los errores a los usuarios por que es una vulnerabilidad
                                        $errors[] = "Error en la consulta".$mysqli->error;
                                    }
                                    
                                }
                                
                                if(count($errors) > 0){
                                    echo "<div class='error'>";
                                    foreach($errors as $error){
                                        echo "<i class='fas fa-exclamation-circle'></i> ".$error."<br>";
                                    }
                                    echo "</div>";
                                }
                                $mysqli->close();
                                ?>
                                <a href="index.php">Regresar a la página de inicio</a>
                            </div>

        </div>
    </div>
</body>
</html>