<?php 
    require('connection.php');
    $errors = array();

    if(isset($_POST['enviar'])){
        //echo "Se envió el formulario";
        //Si se envió el formulario, entonces checamos que todos los valores vengan
        $mi_nombre = $_POST['miNombre'];
        $mi_calificacion = $_POST['miCalificacion'];
        $mi_comentario = $_POST['miComentario'];

        //var_dump($_POST);
        //Validamos que no estén vacíos
        if(!empty($mi_nombre) && !empty($mi_calificacion) && !empty($mi_comentario)){
        //Este IF se lee, si mi_nombre no está vacío y mi_calificación no esta vacío y mi_comentario no está vacío
        $mi_fecha = date("Y-m-d H:i:s");
            $sql = "INSERT INTO comentarios(id,nombre, comentario, fecha, calificacion) VALUES(NULL, '$mi_nombre', '$mi_comentario', '$mi_fecha', '$mi_calificacion')";
             $result = $mysqli->query($sql);
        }else{
            //Si alguna de los tres está vacío entonces es incorrecto.
            $errors[] = "Rellena todos los campos";
        }
    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de comentarios</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet"> 
    <link href="css/all.min.css" rel="stylesheet">
</head>
<body>
    
    <div class="container">
        <div class="comentarios">
            <h2>Insertar comentario</h2>
            <?php
                //Checamos si se ejecutó correctamente nuestro código
                if(isset($result)){
                    //Checamos si la variable $Result está definidca, lo cual significa que entró en el sql
                    if($result){
                        //Checamos el resultado de $result, para ver si la consulta se ejecutó correctamente
                        echo "<div class='success'><i class='fas fa-check-circle'></i> Comentario agregado correctamente</div>";
                    }else{
                        $errors[] = "Sucedió un error".$mysqli->error;
                    }
                }

            ?>
            <?php                 
                    if(count($errors) > 0){
                        echo "<div class='error'>";
                        foreach($errors as $error){
                            echo "<i class='fas fa-exclamation-circle'></i> ".$error."<br>";
                        }
                        echo "</div>";
                    }

            ?>
                            <div class="formulario">
                                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                                    <label for="">Nombre</label>
                                    <input type="text" name="miNombre" >
                                    <label for="">Calificación</label>
                                    1
                                    <input type="radio" name="miCalificacion" value="1">
                                    2
                                    <input type="radio" name="miCalificacion" value="2">
                                    3
                                    <input type="radio" name="miCalificacion" value="3">
                                    4
                                    <input type="radio" name="miCalificacion" value="4">
                                    5
                                    <input type="radio" name="miCalificacion" value="5" checked>
                                    <label for="">Comentario</label>
                                    <textarea name="miComentario" id="" cols="30" rows="10"></textarea>
                                    <input type="submit" value="Enviar" name="enviar">
                                </form>

                            </div>
                            <a href="index.php">Regresar a la página de inicio</a>

        </div>
    </div>
</body>
</html>