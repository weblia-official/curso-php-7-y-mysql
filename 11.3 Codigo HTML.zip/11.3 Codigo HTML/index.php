<?php 
    require('connection.php');

    $errors = array();
    $sql = "SELECT * FROM comentarios";

    $result = $mysqli->query($sql);

    //var_dump($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de comentarios</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet"> 
    <link href="css/all.min.css" rel="stylesheet">
</head>
<body>
    
    <div class="container">
        <div class="comentarios">
            <h2>Sistema de comentarios</h2>
            <?php
                    if($result){
                        if($result->num_rows > 0){
                            while($comentario = $result->fetch_assoc()){
                                //Podemos imprimir con un var dump cada fila que nos devuelve, en este caso sería un arreglo guardado en la variable comentario
                                //var_dump($comentario);
                ?>
                                <div class="comentario">
                                        <p><span>Autor: </span><?php echo $comentario['nombre']; ?></p>
                                        <p><span>Calificación: </span><?php echo $comentario['calificacion']; ?></p>
                                        <p><span>Fecha: </span><?php echo $comentario['fecha']; ?></p>
                                        <p><span>Comentario: </span><?php echo $comentario['comentario']; ?></p>
                                        <div class="acciones">
                                        <a href="borrar.php?id=<?php echo $comentario['id']; ?>"><button class="borrar"><i class="fas fa-trash"></i> Borrar</button></a>
                                        <a href="editar.php?id=<?php echo $comentario['id']; ?>"><button class="editar"><i class="fas fa-edit"></i> Editar</button></a>  
                                        </div>
                                        
                                    
                                </div>
                <?php
                            }
                        }else{
                            $errors[] = "No hay ningún comentario";
                        }
                    }else{
                        $errors[] = "Hubo un error en la consulta".$mysqli->error;
                    }

                    if(count($errors) > 0){
                        echo "<div class='error'>";
                        foreach($errors as $error){
                            echo "<i class='fas fa-exclamation-circle'></i> ".$error."<br>";
                        }
                        echo "</div>";
                    }
            ?>

        </div>
    </div>
    <div class="btn-add">
        <a href="insertar.php"><i class="fas fa-plus-circle"></i></a>
    </div>
</body>
</html>