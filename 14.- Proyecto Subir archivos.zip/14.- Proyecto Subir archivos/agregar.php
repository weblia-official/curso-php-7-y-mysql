<?php
session_start();
require('functions/connection.php');
require('functions/functions.php');


if(!isset($_SESSION['user'])){
    //Si no existe la session, significa que no están logueados
    header('Location:login.php');
}

$errors = array();
//Comenzamos a procesar el formulario
if(isset($_POST['enviar'])){
    //Vemos que se haya enviado el form
    //Guardamos las variables para insertarlas en la base de datos.
    $id = NULL;
    $idUsuario = $_SESSION['id'];
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $fechaCarpeta = date("Y-m-d");

    $tipos = array('image/png', 'image/jpeg');
        //Checamos que el tipo de archivo esté en nuestro arreglo
        if(in_array($_FILES['miArchivo']['type'], $tipos)){
            //Si entra significa que el tipo es correcto
             //8 bits = 1 byte
            //1024 bytes = 1 kilobyte
            //1024 kilobytes = 1 Megabyte
            $tamanio = 1024 * 1024 * 10;
            //        1024 bytes * 1024 kilobytes = 1 mb;

            if($_FILES['miArchivo']['size'] < $tamanio){
                //Si el archivo cumple el tamaño

                //Subimos el archivo
                $carpeta = "publicaciones/";
                echo $carpeta;
                if(!file_exists($carpeta)){
                    //Si la carpeta publicaciones no existe la creamos

                    mkdir($carpeta);
                }

                $carpeta .= "$idUsuario/";
                echo $carpeta;
                if(!file_exists($carpeta)){
                    //Si la carpeta publicaciones/idUsuario/ no existe la creamos

                    mkdir($carpeta);
                }
                $carpeta .=  "$fechaCarpeta/";
                echo $carpeta;
                //Vamos a checar si no existe la carpeta
                if(!file_exists($carpeta)){
                    //Si la carpeta completa con la fecha no existe la creamos

                    mkdir($carpeta);
                }

                $tipo = $_FILES['miArchivo']['type'];
                $fecha = date('Ymd-His');
                echo "<br>".$tipo."<br>";
                if(strcmp($tipo,"image/jpeg") == 0){
                    $archivo = $carpeta.$fecha.".jpg";
                }else{
                    $archivo = $carpeta.$fecha.".png";
                }

    
                $tmpName = $_FILES['miArchivo']['tmp_name'];
                if(!file_exists($archivo)){
                    //Si el archivo no existe
                    if(move_uploaded_file($tmpName,$archivo)){
                        
                        //Si el archivo se subió correctamente procedemos a subir a la base de datos
                        $sql = "INSERT INTO publicaciones(id,titulo,contenido,imagen,usuario_id) VALUES(?,?,?,?,?)";

                        $stmt = $mysqli->prepare($sql);
                    
                        $stmt->bind_param("isssi", $id,$titulo,$contenido,$archivo,$idUsuario);

                        if($stmt->execute()){
                            $resultado = "Publicación insertada correctamente";
                        }else{
                            $errors[] = "Hubo un error al agregar la publicación";
                        }
                    }
                }else{
                    $errors[] = "El archivo ya existe";
                }
            }else{
                $errors[] = "El archivo excede el tamaño permitido de 10Mb";
            }
        }else{
            $errors[] = "El tipo no es compatible, solo aceptamos PNG y JPG";
        }

}
?>
<?php include('templates/header.php'); ?>
    <div class="container">
        <div class="row mt-5">

            <div class="col-8 m-auto bg-white rounded shadow p-0">
                <h4 class="text-center mb-4 text-secondary mt-5">Agregar publicación</h4>
                <div class="col-12 bg-light py-3 mb-5 text-center">
                <a href="index.php"><button class="btn btn-success m-auto">Regresar a la página de inicio</button></a>
                </div>
                <?php
                    if(isset($resultado)){
                    ?>
                    <div class="bg-success text-white p-2 mx-5 text-center">
                        <?php echo $resultado; ?>
                    </div>
                    <?php
                    }
                    include('functions/errors.php');
                    ?>
                <div class="px-5 pb-5">
                <h4>Estás logueado como: <?php echo $_SESSION['user']; ?> </h4>

                <h3>Agregar una nueva publicación</h3>

                  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        Título de la publicación:
                        <input type="text" class="form-control" name="titulo" placeholder="Título de la publicación">
                    </div>
                    <div class="form-group">
                        Contenido de la publicación:
                        <textarea name="contenido" class="form-control" id="" cols="30" rows="10"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="file" name="miArchivo" class="form-control">
                    </div>
                    <div class="form-group text-right">
                       <button class="btn btn-primary ml-auto" name="enviar" type="submit">Subir publicación</button> 
                    </div>
                    
                  </form>
                </div>
                
                <div class="col-4 m-5">
                            <a href="logout.php"><button class="btn btn-outline-secondary form-control">Cerrar sesión</button></a>
                            <p class="text-secondary text-center">¿Quieres cerrar sesión?</p>
                </div>
            </div>
        </div>
    </div>
    <?php include('templates/footer.php'); ?>