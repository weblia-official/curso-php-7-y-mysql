<?php


function esVacia($usuario, $contrasena, $repContrasena){

    if(!empty(trim($usuario)) && !empty(trim($contrasena)) && !empty(trim($repContrasena))){
        //si ningún campo está vacio, retornamos FALSE
        return FALSE;
    }else{
        //Si algún campo está vacío retornamos TRUE
        return TRUE;
    }
}

function validaLargo($usuario){
    if(strlen(trim($usuario)) > 3 && strlen(trim($usuario)) < 20){
        //Si la cadena tiene más de tres y menos de 20 caracteres, regresamos TRUE
        return TRUE;
    }else{
        //Si la cadena no cumple con los caracteres retornamos FALSE
        return FALSE;
    }
}

function usuarioExiste($usuario){
    global $mysqli;

    $_usuario = trim($usuario);

    $sql = "SELECT id FROM users WHERE usuario = ?";

    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s",$_usuario);

    $stmt->execute();

    $stmt->store_result();

    $numRows = $stmt->num_rows;
    $stmt->close();

    if($numRows > 0){
        //sI NUMROWS > 0 significa que el usuario ya existe
        return TRUE;
    }else{
        return FALSE;
    }
}

function contrasenasIguales($contrasena, $repContrasena){

    if(strcmp($contrasena,$repContrasena) == 0){
        //strcmp nos devuelve cero si son iguales
        return TRUE;
    }else{
        //Las contraseñas no son iguales
        return FALSE;
    }
}

function hashContrasena($contrasena){
    $hash = password_hash($contrasena, PASSWORD_DEFAULT);
    return $hash;
}

function registra($usuario, $contrasena){
    global $mysqli;

    $_usuario = trim($usuario);
    $fecha = date("Y-m-d H:i:s");

    $id = NULL;
    $ultima = NULL;
    //Aqui la contraseña ya debe venir hasehada

    $sql = "INSERT INTO users(usuario, contrasena,fecha_registro) VALUES(?,?,?)";

    $stmt = $mysqli->prepare($sql);

    $stmt->bind_param("sss", $_usuario, $contrasena, $fecha);

    if($stmt->execute()){
        //Si regresamos true significa que el usuario se registró
        $stmt->close();
        return TRUE;
    }else{
        $stmt->close();
        return FALSE;
    }
}

function loginVacio($usuario, $contrasena){
    if(!empty(trim($usuario)) && !empty(trim($contrasena))){
        return FALSE;
    }else{
        //sI EL LOGIN VIENE VACÍO RETORNAMOS TRUE;
        return TRUE;
    }
}

function login($usuario,$contrasena){
    global $mysqli;

    $sql = "SELECT id, contrasena FROM users WHERE usuario = ?";

    $stmt = $mysqli->prepare($sql);

    $stmt->bind_param("s", $usuario);

    $stmt->execute();

    $stmt->store_result();

    //Checar que sí trngamos ese usuario

    $numRows = $stmt->num_rows;

    if($numRows > 0){
        //Significa que ese usuario existe

        $stmt->bind_result($id,$contra);

        $stmt->fetch();

        //Validar la contraseña
        $contraValidada = password_verify($contrasena, $contra);

        if($contraValidada){
            //La contraseña es válida

            $_SESSION['user'] = $usuario;
            $_SESSION['id'] = $id;
            //Lastsession actualizaría la última conexion del usuario
            $lastSession = lastSession($id);
            //Reedirigimos a la página de inicio
            header('Location:index.php');
        }else{
            return "Las contraseñas no coinciden";
        }
    }else{
        return "Ese usuario no existe";
    }
}

function lastSession($id){
    global $mysqli;

    $stmt = $mysqli->prepare("UPDATE users SET ultima_conexion=NOW() WHERE id=?");

    $stmt->bind_param("i",$id);

    if($stmt->execute()){
        if($stmt->affected_rows > 0){
            //Si las filas afectadas son mayor a cero, significa que modificamos correctamente la última conexión
            $stmt->close();
            return TRUE;
        }else{
            $stmt->close();
            return FALSE;
        }
    }else{
        $stmt->close();
        return FALSE;
    }
}