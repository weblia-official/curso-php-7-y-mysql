<?php

if(isset($_SESSION['user'])){
    //Si existe la sesión que se llama user, significa que estamos logueados
    header('Location:index.php');
}